var groceryList = ["Bananas", "milk", "Eggs", "Bacon"];

var message = "Please pick up the following from the store: ";

// loop through the array length
// add message to groceryList array
// if the index isn't the end length then add a comma after the array item
for (var i = 0; i < groceryList.length; i++) {
  message += groceryList[i];
  if (i < groceryList.length - 1) {
    message += ", ";
  }
}

console.log(message);
